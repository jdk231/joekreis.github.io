
import { GoogleGenAI, Type } from "@google/genai";
import { SecurityReport } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getSecurityReport = async (): Promise<SecurityReport> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Generate a funny, cute Web 2.0 style 'security threat assessment' for a girlfriend who accidentally clicked a valentine phishing link. Keep it silly. The threat level should be something like 'CRITICALLY ADORABLE'. Provide 3 funny remedies.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            threatLevel: { type: Type.STRING },
            reason: { type: Type.STRING },
            remedy: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["threatLevel", "reason", "remedy"]
        }
      }
    });

    return JSON.parse(response.text || '{}') as SecurityReport;
  } catch (error) {
    console.error("Error fetching security report:", error);
    return {
      threatLevel: "EXTREME CUTENESS OVERLOAD",
      reason: "User has been identified as being 'way too cute' for public servers.",
      remedy: [
        "Immediately cease being so adorable.",
        "Accept the upcoming Valentine's request.",
        "Provide unlimited forehead kisses."
      ]
    };
  }
};

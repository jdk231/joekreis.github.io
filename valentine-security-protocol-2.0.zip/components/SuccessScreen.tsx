
import React, { useEffect, useState } from 'react';

const SuccessScreen: React.FC = () => {
  const [hearts, setHearts] = useState<{ id: number; left: string; delay: string; size: string }[]>([]);

  useEffect(() => {
    const newHearts = Array.from({ length: 30 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      delay: `${Math.random() * 5}s`,
      size: `${Math.random() * 2 + 1}rem`
    }));
    setHearts(newHearts);
  }, []);

  return (
    <div className="text-center space-y-8 max-w-2xl">
      <div className="relative inline-block">
        <img 
          src="https://picsum.photos/seed/valentine/600/400" 
          alt="Celebration" 
          className="rounded-3xl border-8 border-white shadow-[0_30px_60px_rgba(0,0,0,0.3)] glossy-button transform rotate-2"
        />
        <div className="absolute -top-10 -right-10 bg-yellow-400 text-white p-4 rounded-full bubble-font text-2xl shadow-xl animate-bounce border-4 border-white">
          BEST CHOICE!
        </div>
      </div>

      <div className="space-y-4">
        <h1 className="text-6xl md:text-8xl bubble-font text-pink-600 drop-shadow-2xl">
          YAYYY! 🎉
        </h1>
        <p className="text-2xl md:text-3xl comic-font text-pink-500 font-bold italic">
          I knew you couldn't resist! <br/> I love you so much! ❤️
        </p>
      </div>

      <div className="bg-white/80 p-6 rounded-2xl shadow-inner border-2 border-pink-100 inline-block">
        <p className="text-pink-400 font-bold text-lg uppercase tracking-widest">
          Valentine Status: SECURED ✅
        </p>
      </div>

      {/* Falling Hearts Animation */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-50">
        {hearts.map(heart => (
          <div
            key={heart.id}
            className="absolute top-[-10%] animate-[fall_5s_linear_infinite]"
            style={{
              left: heart.left,
              animationDelay: heart.delay,
              fontSize: heart.size
            }}
          >
            💖
          </div>
        ))}
      </div>

      <style>
        {`
          @keyframes fall {
            0% { transform: translateY(0vh) rotate(0deg); opacity: 1; }
            100% { transform: translateY(110vh) rotate(360deg); opacity: 0; }
          }
        `}
      </style>
    </div>
  );
};

export default SuccessScreen;


import React, { useState, useRef, useEffect } from 'react';

interface ValentineScreenProps {
  onYes: () => void;
}

const ValentineScreen: React.FC<ValentineScreenProps> = ({ onYes }) => {
  const [yesScale, setYesScale] = useState(1);
  const [noPosition, setNoPosition] = useState({ top: '50%', left: '50%' });
  const [isMoved, setIsMoved] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleNoInteraction = () => {
    // Increase Yes button size
    setYesScale(prev => prev + 0.5);

    // Randomize No button position
    if (containerRef.current) {
      const container = containerRef.current.getBoundingClientRect();
      const buttonWidth = 100;
      const buttonHeight = 50;
      
      const newTop = Math.random() * (container.height - buttonHeight);
      const newLeft = Math.random() * (container.width - buttonWidth);
      
      setNoPosition({ top: `${newTop}px`, left: `${newLeft}px` });
      setIsMoved(true);
    }
  };

  return (
    <div className="max-w-4xl w-full flex flex-col items-center space-y-12">
      <div className="text-center space-y-4">
        <h2 className="text-5xl md:text-7xl bubble-font text-pink-600 drop-shadow-lg animate-bounce">
          Will you be my Valentine?
        </h2>
        <p className="text-xl md:text-2xl comic-font text-pink-400 font-bold italic">
          (There is only one correct answer!)
        </p>
      </div>

      <div 
        ref={containerRef}
        className="relative w-full h-[400px] flex items-center justify-center bg-white/30 backdrop-blur-sm rounded-3xl border-4 border-dashed border-pink-300"
      >
        <div className="flex items-center justify-center gap-8">
          <button
            onClick={onYes}
            style={{ transform: `scale(${yesScale})` }}
            className="z-50 bg-green-500 hover:bg-green-600 text-white font-black px-12 py-6 rounded-full glossy-button text-3xl transition-transform duration-300 shadow-2xl active:scale-90"
          >
            YES! 😍
          </button>

          <button
            onMouseEnter={handleNoInteraction}
            onClick={handleNoInteraction}
            style={isMoved ? { position: 'absolute', top: noPosition.top, left: noPosition.left } : {}}
            className="bg-gray-400 hover:bg-gray-500 text-white font-bold px-8 py-4 rounded-full glossy-button text-xl transition-all duration-100 shadow-lg"
          >
            No 😢
          </button>
        </div>

        {!isMoved && (
          <div className="absolute bottom-4 text-pink-300 italic text-sm animate-pulse">
            Try to click 'No'... I dare you!
          </div>
        )}
      </div>

      <div className="flex gap-4">
        {[...Array(5)].map((_, i) => (
          <span key={i} className={`text-3xl animate-float`} style={{ animationDelay: `${i * 0.2}s` }}>💖</span>
        ))}
      </div>
    </div>
  );
};

export default ValentineScreen;

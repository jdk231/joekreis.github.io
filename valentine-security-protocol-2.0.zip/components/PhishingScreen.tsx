
import React, { useState, useEffect } from 'react';
import { getSecurityReport } from '../services/geminiService';
import { SecurityReport } from '../types';

interface PhishingScreenProps {
  onAcknowledge: () => void;
}

const PhishingScreen: React.FC<PhishingScreenProps> = ({ onAcknowledge }) => {
  const [report, setReport] = useState<SecurityReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReport = async () => {
      const data = await getSecurityReport();
      setReport(data);
      setLoading(false);
    };
    fetchReport();
  }, []);

  return (
    <div className="max-w-xl w-full bg-white border-4 border-red-500 rounded-xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.2)] animate-float">
      {/* Windows Style Header */}
      <div className="bg-red-500 p-3 flex items-center justify-between text-white">
        <div className="flex items-center gap-2">
          <span className="text-xl">⚠️</span>
          <span className="font-bold uppercase tracking-wider text-sm">System Alert: Security Breach</span>
        </div>
        <div className="flex gap-1">
          <div className="w-4 h-4 bg-white/30 rounded-sm"></div>
          <div className="w-4 h-4 bg-white/30 rounded-sm"></div>
          <div className="w-4 h-4 bg-white/80 rounded-sm text-red-500 flex items-center justify-center text-[10px] font-bold">X</div>
        </div>
      </div>

      <div className="p-8 space-y-6">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-red-600 mb-2 uppercase italic tracking-tighter">OOPS!</h1>
          <p className="text-gray-600 font-semibold text-lg">You just clicked on a highly suspicious Valentine link!</p>
        </div>

        <div className="bg-red-50 p-4 rounded-lg border-2 border-red-100 space-y-3">
          <h2 className="font-black text-red-700 flex items-center gap-2">
            <span className="text-xl">🔍</span> SCANNING FOR THREATS...
          </h2>
          
          {loading ? (
            <div className="flex flex-col items-center py-4 gap-2">
              <div className="w-full bg-gray-200 h-4 rounded-full overflow-hidden">
                <div className="bg-red-500 h-full w-2/3 animate-[pulse_1.5s_infinite]"></div>
              </div>
              <p className="text-xs text-red-400 animate-pulse font-mono">Analyzing charm levels...</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <span className="text-xs font-bold text-red-400 uppercase">Threat Level:</span>
                <div className="text-2xl font-black text-red-600 bubble-font italic tracking-widest uppercase">
                  {report?.threatLevel}
                </div>
              </div>
              <p className="text-sm text-gray-700 italic border-l-4 border-red-400 pl-3">
                "{report?.reason}"
              </p>
              
              <div>
                <span className="text-xs font-bold text-red-400 uppercase mb-2 block">Required Remedies:</span>
                <ul className="space-y-2">
                  {report?.remedy.map((step, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-800 font-medium">
                      <span className="text-red-500 font-bold">{i + 1}.</span>
                      {step}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-col items-center gap-4 pt-4">
          <button 
            onClick={onAcknowledge}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-black py-4 rounded-full glossy-button text-xl uppercase tracking-widest shadow-xl transform active:scale-95 transition-all"
          >
            I Accept the Risks (and the Love)
          </button>
          <p className="text-[10px] text-gray-400 text-center px-8 italic">
            By clicking this button, you agree to be 10% more adorable today and accept all consequences related to upcoming romantic gestures.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PhishingScreen;
